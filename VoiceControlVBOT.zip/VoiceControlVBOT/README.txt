Team: VBOT
Members: Varun Katragadda and Shweta Aswani

The IDE used for the code is Arduino IDE
The tick mark used is to verify the code
After that we need to upload the code in Arduino IDE, but before uploading remember to remove the transmitter and receiver wires from Bluetooth module.

For Voice Control feature, download the Arduino Bluetooth Controller app from Play Store, in which you need to connect your device, i  our case  it is HC-05 as the Bluetooth module is HC-05.

After the device is connected, select voice control.
The commands used are as follows:
1) Ahead
2)Behind
3)Left
4)Right